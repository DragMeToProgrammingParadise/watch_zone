-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.30 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for watch_zone
DROP DATABASE IF EXISTS `watch_zone`;
CREATE DATABASE IF NOT EXISTS `watch_zone` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `watch_zone`;

-- Dumping structure for table watch_zone.menu
DROP TABLE IF EXISTS `menu`;
CREATE TABLE IF NOT EXISTS `menu` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `description` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `target` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `link` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

-- Dumping data for table watch_zone.menu: ~0 rows (approximately)
DELETE FROM `menu`;

-- Dumping structure for table watch_zone.orders
DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci NOT NULL DEFAULT '0',
  `last_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci NOT NULL DEFAULT '0',
  `price` float unsigned NOT NULL DEFAULT '0',
  `quantity` int DEFAULT NULL,
  `total` float DEFAULT NULL,
  `delivery_charges` float DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `address` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci NOT NULL DEFAULT '0',
  `city` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci NOT NULL DEFAULT '0',
  `country` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci NOT NULL DEFAULT '0',
  `zip` int NOT NULL DEFAULT '0',
  `mobile` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci NOT NULL DEFAULT '0',
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT '0',
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci NOT NULL DEFAULT '0',
  `tracking_num` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT '0',
  `discount` float DEFAULT NULL,
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int unsigned NOT NULL DEFAULT '0',
  `product_id` int unsigned NOT NULL DEFAULT '0',
  `payment` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

-- Dumping data for table watch_zone.orders: ~3 rows (approximately)
DELETE FROM `orders`;
INSERT INTO `orders` (`id`, `first_name`, `last_name`, `price`, `quantity`, `total`, `delivery_charges`, `amount`, `address`, `city`, `country`, `zip`, `mobile`, `email`, `status`, `tracking_num`, `discount`, `created_at`, `updated_at`, `user_id`, `product_id`, `payment`) VALUES
	(64, 'waqar', 'hussain', 0, NULL, NULL, 300, 50300, 'shahi road ', 'Karachi', 'Pakistan', 64200, '3338000128', 'waqaar.hussaiin@gmail.com', '3', 'WTCHZN-11861616246', NULL, '2022-11-02 06:18:21', NULL, 11, 0, 'on'),
	(65, 'azaan', 'hussain', 0, NULL, NULL, 300, 32300, 'shahi road ', 'Zahir pir', 'Pakistan', 64200, '3338000128', 'smartwiki009@gmail.com', '1', 'WTCHZN-11963599776', NULL, '2022-11-03 13:12:02', NULL, 11, 0, 'on'),
	(66, 'ali', 'hussain', 0, NULL, NULL, 300, 132300, 'thana road', 'Lahore', 'Pakistan', 64200, '3338000128', 'waqaar.hussaiin@gmail.com', '1', 'WTCHZN-11696498497', NULL, '2022-11-03 13:15:27', NULL, 11, 0, 'on');

-- Dumping structure for table watch_zone.order_meta
DROP TABLE IF EXISTS `order_meta`;
CREATE TABLE IF NOT EXISTS `order_meta` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `product_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci,
  `quantity` int DEFAULT NULL,
  `price` float DEFAULT NULL,
  `sub_total` float DEFAULT NULL,
  `orders_id` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

-- Dumping data for table watch_zone.order_meta: ~7 rows (approximately)
DELETE FROM `order_meta`;
INSERT INTO `order_meta` (`id`, `product_name`, `title`, `description`, `quantity`, `price`, `sub_total`, `orders_id`) VALUES
	(76, 'Apple Smart Watch', NULL, 'Classy apple smart watch that is made for men with glossy outlook.', 1, 25000, 25000, 64),
	(77, 'Android Smart Watch', NULL, 'Classy apple smart watch that is made for men with glossy outlook.', 1, 25000, 25000, 64),
	(78, 'Apple Smart Watch', NULL, 'Classy apple smart watch that is made for men with glossy outlook.', 1, 32000, 32000, 65),
	(79, 'Android Smart Watch', NULL, 'Classy apple smart watch that is made for men with glossy outlook.', 1, 25000, 25000, 66),
	(80, 'Apple Smart Watch', NULL, 'Classy apple smart watch that is made for men with glossy outlook.', 1, 37000, 37000, 66),
	(81, 'A watch by Android', NULL, 'Classy apple smart watch.', 1, 30000, 30000, 66),
	(82, 'Android Smart Watch', NULL, 'Classy apple smart watch that is made for men with glossy outlook.', 1, 40000, 40000, 66);

-- Dumping structure for table watch_zone.pages
DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `type` int DEFAULT NULL,
  `title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci,
  `link` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `target` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

-- Dumping data for table watch_zone.pages: ~3 rows (approximately)
DELETE FROM `pages`;
INSERT INTO `pages` (`id`, `type`, `title`, `description`, `link`, `target`, `created_at`, `updated_at`) VALUES
	(1, 1, 'Contact Us', '<section class="mb-4">\n\n    <!--Section heading-->\n    <h2 class="h1-responsive font-weight-bold text-center my-4">Contact us</h2>\n    <!--Section description-->\n    <p class="text-center w-responsive mx-auto mb-5">Do you have any questions? Please do not hesitate to contact us\n      directly. Our team will come back to you within\n      a matter of hours to help you.</p>\n\n    <div class="row align-items-center justify-content-center">\n\n      <!--Grid column-->\n      <div class="col-md-9 mb-md-0 mb-5">\n        <form id="contact-form" name="contact-form" action="mail.php" method="POST">\n\n          <!--Grid row-->\n          <div class="row">\n\n            <!--Grid column-->\n            <div class="col-md-6">\n              <div class="md-form mb-0">\n                <input type="text" id="name" name="name" class="form-control">\n                <label for="name" class=" mb-4">Your name</label>\n              </div>\n            </div>\n            <!--Grid column-->\n\n            <!--Grid column-->\n            <div class="col-md-6 myclass">\n              <div class="md-form mb-0">\n                <input type="text" id="email" name="email" class="form-control">\n                <label for="email" class=" mb-4">Your email</label>\n              </div>\n            </div>\n            <!--Grid column-->\n\n          </div>\n          <!--Grid row-->\n\n          <!--Grid row-->\n          <div class="row">\n            <div class="col-md-12">\n              <div class="md-form mb-0">\n                <input type="number" id="mobile-number" name="mobile-number" class="form-control">\n                <label for="mobile-number" class="mb-4">Mobile Number</label>\n              </div>\n            </div>\n          </div>\n          <!--Grid row-->\n\n          <!--Grid row-->\n          <div class="row">\n            <div class="col-md-12">\n              <div class="md-form mb-0">\n                <input type="text" id="subject" name="subject" class="form-control">\n                <label for="subject" class="mb-4">Subject</label>\n              </div>\n            </div>\n          </div>\n          <!--Grid row-->\n\n          <!--Grid row-->\n          <div class="row">\n\n            <!--Grid column-->\n            <div class="col-md-12">\n\n              <div class="md-form">\n                <textarea type="text" id="message" name="message" rows="2" class="form-control md-textarea"></textarea>\n                <label for="message" class="mb-2">Your message</label>\n              </div>\n\n            </div>\n          </div>\n          <!--Grid row-->\n\n        </form>\n\n        <div class="text-center text-md-left">\n          <a class="btn btn-outline-danger" onclick="document.getElementById(\'contact-form\').submit();">Send</a>\n        </div>\n        <div class="status"></div>\n      </div>\n\n\n\n\n    </div>\n\n  </section>', 'conatct.php', NULL, '2022-10-18 10:48:27', '2022-10-18 10:48:28'),
	(2, 1, 'About Us', '<div class="container mt-2 mb-2">\n      <div class="container-fluid">\n    <h1 class="text-center bg-light mt-4 mb-4">About Us</h1>\n    <p>Watch Zone is the leading online watch store in Pakistan, since 2022. We sell 100% original and\n        branded watches &amp; provide one year warranty. Some of the leading brands in our watch collection includes Casio,\n        Q&amp;Q by Citizen, NaviForce, Benyar, Timex &amp; more.</p>\n\n    <p> We deliver your favorite watch at your door step in Pakistan. We offer delivery to any location in Pakistan,\n        where courier service is present. We also offer cash on delivery payment method, allowing you to pay for your\n        watch once you’ve receive the order. We also provide standard warranty for the watches as well. </p>\n\n    <p class="mb-5"> Our diverse range of watches include men’s watches, ladies watches, youth watches, sports watches, smart\n        watches, vintage watches &amp; more. Browse our collection of watches and order one of your favorite watch online.\n    </p>\n</div>\n</div>', 'about.php', NULL, '2022-10-18 10:48:48', '2022-10-18 10:48:49'),
	(3, 2, 'Privacy & Policy', '<div class="container mt-2 mb-2">\n  <div class="mt-4 mb-4 container-fluid">\n  <h1 class="text-center bg-light">PURCHASING POLICY</h1>\n  <p>ONLINE PURCHASING: <br>\n\n    Watches purchased from Watch Zone may only be shipped for delivery within Pakistan. We are unable to ship internationally.\n    \n    Prices of all products are now inclusive of VAT. <br>\n    \n    All products are subject to availability. In the event that we are out of stock, you will be notified by the next business day. We reserve the right to limit the quantity of products we supply; to supply only part of an order; or to divide an order into multiple shipments to expedite delivery. We also reserve the right to change the terms or duration of any special offers or sales promotions.\n    \n    PAYMENT <br>\n    \n    Citizen accepts the following forms of payment for in store purchases: <br>\n    \n    Visa <br>\n    MasterCard <br>\n     \n    \n    SHIPPING AND DELIVERY: <br>\n    \n    Your order will be fulfilled by Citizen distributed in Citizen Pakistan. Upon delivery you will receive VAT invoice issued by International Watch Company\n    \n    Citizen offers delivery service through our Courier Company to all locations in Pakistan. You can order from us and get the delivery at your home or at your office as specified in the ‘Shipping Details’ in your profile with iwc.com.pk/citizen.\n    \n    Our Courier Company will contact you to arrange delivery at your convenience as per the following: <br>\n    \n    3 calls per shipment to find your exact address. <br>\n    2 delivery attempts per shipment. <br>\n    Orders will be delivered to your ‘Shipping Address’ within 4 to 5 working days if the location is within the serviceable area.\n    \n    Any territory falls outside the delivery parameter, or in case the defined ‘Shipping Address’ is not reachable, The courier company will contact you to receive the order from their nearest office or a pre agreed location. <br>\n    \n     \n    \n    TRACKING: <br>\n    \n    As soon as your purchase ships, we will email you a shipping confirmation which will allow you to track the status of your shipment online.\n    \n     <br>\n    \n    CANCELLATIONS: <br>\n    \n    You may cancel your order provided the order has not been shipped yet from our warehouse. Once the watch has been shipped we will not be able to accommodate the cancellation request. Please call customer service at 0333-8000128, Monday – Saturday from 11am to 8pm. <br> </p>\n</div>\n<div class="container-fluid">\n<h1 class="text-center mt-4 mb-4 bg-light">ONLINE RETURN POLICY</h1>\n<p>\n    Returns can only be accepted for products purchased on the Citizen Online Store. <br>\n\nReport any discrepancy in shipment or damages to Customer Service at 0333-8000128 <br>\n\nYou may return any unworn, undamaged watch, within 14 days of delivery for a full refund of purchase price (minus shipping and handling fees). <br>\n\nAny watch that fails quality inspection from Customer Service (scratches, worn, damaged) will be returned to you and no refund will be issued. <br>\n\nPlease note that we do not accept returns once the watch bracelet has been sized. Rubber straps improperly sized (cut) are not returnable or exchangeable. Rubber straps replacements can be ordered at an additional cost with the customer service at 0333-8000128.\n\nRefunds can only be placed back onto the original method of payment. <br>\n\nShould you need to return merchandise, <br>\n\nPlease include copy of the invoice while you ship the watch back. <br>\nWatch needs to be returned with box, warranty cards, user manual, and any extra links due to bracelet sizing. In the case that any of these items are not returned, additional charges will be applied. <br>\nCarefully package merchandise to prevent damage in transit. <br>\nSend package using TCS or any reputed courier so that you can track the shipment and insure the contents of the package before dispatch. <br>\n</p>\n</div>\n</div>', 'privacy.php', NULL, '2022-10-18 10:53:03', '2022-10-18 10:53:04');

-- Dumping structure for table watch_zone.products
DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `type` int DEFAULT NULL,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `description` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `price` float DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `image` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `category_id` int DEFAULT NULL,
  `status` int DEFAULT NULL COMMENT '1 = active 0 =inactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

-- Dumping data for table watch_zone.products: ~26 rows (approximately)
DELETE FROM `products`;
INSERT INTO `products` (`id`, `type`, `name`, `description`, `price`, `quantity`, `image`, `created_at`, `updated_at`, `category_id`, `status`) VALUES
	(1, 1, 'A watch by Android', 'Classy apple smart watch.', 30000, 2, '1667656624_1667656347_watch9.jpeg', '2022-10-18 11:52:37', '2022-11-05 13:57:04', 1, 1),
	(2, 1, 'A Watch by Apple', 'Classy android smart watch.', 25000, 3, '1667653232_watch2.jpeg', '2022-10-18 11:57:36', '2022-11-05 13:00:32', 1, 1),
	(3, 1, 'A watch by Android', 'Classy apple smart watch.', 12000, 2, '1667653262_watch3.jpeg', '2022-10-18 11:58:15', '2022-11-05 13:01:02', 1, 1),
	(4, 1, 'A Watch by Apple', 'Classy android smart watch.', 25000, 7, '1667655580_watch4.jpeg', '2022-10-18 11:59:23', '2022-11-05 13:39:40', 1, 1),
	(5, 1, 'A watch by Android', 'Classy apple smart watch.', 37000, 9, '1667655621_watch4.jpeg', '2022-10-18 12:00:23', '2022-11-05 13:40:21', 1, 1),
	(6, 4, 'Android Smart Watch', 'Classy apple smart watch that is made for men with glossy outlook.', 40000, 4, '1667655637_watch5.jpeg', '2022-10-18 12:26:20', '2022-11-05 13:40:37', 4, 1),
	(7, 4, 'Apple Smart Watch', 'Classy apple smart watch that is made for men with glossy outlook.', 37000, 1, '1667656109_watch8.jpeg', '2022-10-18 12:27:48', '2022-11-05 13:48:29', 4, 1),
	(8, 4, 'Android Smart Watch', 'Classy apple smart watch that is made for men with glossy outlook.', 25000, 6, '1667656130_watch2.jpeg', '2022-10-18 12:28:59', '2022-11-05 13:48:50', 4, 1),
	(9, 4, 'Apple Smart Watch', 'Classy apple smart watch that is made for men with glossy outlook.', 17000, 2, '1667656146_watch10.jpeg', '2022-10-18 12:37:12', '2022-11-05 13:49:06', 4, 1),
	(10, 4, 'Android Smart Watch', 'Classy apple smart watch that is made for men with glossy outlook.', 14500, 5, '1667656161_watch12.jpeg', '2022-10-18 12:37:54', '2022-11-05 13:49:21', 4, 1),
	(11, 5, 'Apple Smart Watch', 'Classy apple smart watch that is made for men with glossy outlook.', 25000, 1, '1667655817_watch7.jpeg', '2022-10-18 13:05:34', '2022-11-05 13:43:37', 5, 1),
	(12, 5, 'Android Smart Watch', 'Classy apple smart watch that is made for men with glossy outlook.', 14500, 4, '1667656177_watch10.jpeg', '2022-10-18 13:06:21', '2022-11-05 13:49:37', 5, 1),
	(13, 5, 'Apple Smart Watch', 'Classy apple smart watch that is made for men with glossy outlook.', 17000, 2, '1667656201_watch11.jpeg', '2022-10-18 13:06:59', '2022-11-05 13:50:01', 5, 1),
	(14, 5, 'Android Smart Watch', 'Classy apple smart watch that is made for men with glossy outlook.', 37000, 6, '1667656231_watch13.jpg', '2022-10-18 13:07:58', '2022-11-05 13:50:31', 5, 1),
	(15, 5, 'Apple Smart Watch', 'Classy apple smart watch that is made for men with glossy outlook.', 32000, 3, '1667656263_watch1.jpeg', '2022-10-18 13:08:55', '2022-11-05 13:51:03', 5, 1),
	(16, 6, 'Android Smart Watch', 'Classy apple smart watch that is made for men with glossy outlook.', 17000, 2, '1667656327_1667656231_watch13.jpg', '2022-10-18 13:12:43', '2022-11-05 13:52:07', 6, 1),
	(17, 6, 'Apple Smart Watch', 'Classy apple smart watch that is made for men with glossy outlook.', 14500, 4, '1667656347_watch9.jpeg', '2022-10-18 13:13:36', '2022-11-05 13:52:27', 6, 1),
	(18, 6, 'Android Smart Watch', 'Classy apple smart watch that is made for men with glossy outlook.', 25000, 1, '1667656365_watch7.jpeg', '2022-10-18 13:14:16', '2022-11-05 13:52:45', 6, 1),
	(19, 6, 'Apple Smart Watch', 'Classy apple smart watch that is made for men with glossy outlook.', 37000, 5, '1667656386_watch5.jpeg', '2022-10-18 13:14:58', '2022-11-05 13:53:06', 6, 1),
	(20, 6, 'Android Smart Watch', 'Classy apple smart watch that is made for men with glossy outlook.', 49000, 7, '1667656403_watch8.jpeg', '2022-10-18 13:16:49', '2022-11-05 13:53:23', 6, 1),
	(21, 7, 'Apple Smart Watch', 'Classy apple smart watch that is made for men with glossy outlook.', 14500, 1, '1667656427_watch4.jpeg', '2022-10-18 13:18:37', '2022-11-05 13:53:47', 7, 1),
	(22, 7, 'Android Smart Watch', 'Classy apple smart watch that is made for men with glossy outlook.', 49000, 4, '1667656444_watch17.jpeg', '2022-10-18 13:19:29', '2022-11-05 13:54:04', 7, 1),
	(23, 7, 'Apple Smart Watch', 'Classy apple smart watch that is made for men with glossy outlook.', 37000, 2, '1667656477_watch16.jpeg', '2022-10-18 13:20:07', '2022-11-05 13:54:37', 7, 1),
	(24, 7, 'Android Smart Watch', 'Classy apple smart watch that is made for men with glossy outlook.', 11000, 6, '1667656495_1667656444_watch17.jpeg', '2022-10-18 13:21:00', '2022-11-05 13:54:55', 7, 1),
	(25, 7, 'Apple Smart Watch', 'Classy apple smart watch that is made for men with glossy outlook.', 16000, 3, '1667656516_1667656427_watch4.jpeg', '2022-10-18 13:21:38', '2022-11-05 13:55:16', 7, 1),
	(26, 1, 'Android Smart Watch', 'Classy apple smart watch that is made for men with glossy outlook.', 12500, 4, '1667656537_watch6.jpeg', '2022-10-18 13:29:51', '2022-11-05 13:55:37', 1, 1);

-- Dumping structure for table watch_zone.product_categories
DROP TABLE IF EXISTS `product_categories`;
CREATE TABLE IF NOT EXISTS `product_categories` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT '0',
  `description` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

-- Dumping data for table watch_zone.product_categories: ~13 rows (approximately)
DELETE FROM `product_categories`;
INSERT INTO `product_categories` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
	(5, 'Smart Watches', 'Men Smart Watches', '2022-10-18 12:20:14', '2022-10-18 12:20:15'),
	(6, 'Fashion Watches', 'Men Fashion Watches', '2022-10-18 12:21:04', '2022-10-18 12:21:05'),
	(7, 'Sports Watches', 'Men Sports Watches', '2022-10-18 12:21:44', '2022-10-18 12:21:46'),
	(8, 'Luxury Watches', 'Women Luxury Watches', '2022-10-18 12:22:18', '2022-10-18 12:22:19'),
	(9, 'Smart Watches', 'Women Smart Watches', '2022-10-18 12:22:46', '2022-10-18 12:22:47'),
	(10, 'Fashion Watches', 'Women Fashion Watches', '2022-10-18 12:23:15', '2022-10-18 12:23:16'),
	(11, 'Sports Watches', 'Women Sports Watches', '2022-10-18 12:23:59', '2022-10-18 12:24:00'),
	(12, 'men watches', 'sports men watches', '2022-11-03 11:08:18', '2022-11-03 11:08:41'),
	(13, 'men watches', 'sports men watches', '2022-11-03 11:10:14', NULL),
	(14, 'women', 'fashion watches for women', '2022-11-03 11:10:51', NULL),
	(15, 'ali', 'sports men watches', '2022-11-03 11:20:03', NULL),
	(16, 'men watches', 'fashion watches for men', '2022-11-03 11:21:58', NULL),
	(17, 'sadia', 'sadia watches', '2022-11-03 11:22:55', '2022-11-03 11:41:36');

-- Dumping structure for table watch_zone.sliders
DROP TABLE IF EXISTS `sliders`;
CREATE TABLE IF NOT EXISTS `sliders` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `type` int DEFAULT NULL,
  `title` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `description` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `link` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `image` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

-- Dumping data for table watch_zone.sliders: ~3 rows (approximately)
DELETE FROM `sliders`;
INSERT INTO `sliders` (`id`, `type`, `title`, `description`, `link`, `image`) VALUES
	(1, 1, 'iWatch', 'Classy and stylish watch by Apple', 'order-now.php', 'http://source.unsplash.com/900x300/?watch,women'),
	(2, 1, 'Android Watch', 'Classy and stylish watch Android', 'order-now.php', 'http://source.unsplash.com/900x300/?watch,apple'),
	(3, 1, 'Kalvin Clein Watch ', 'Stylish Watch for new era ', 'order-now.php', 'http://source.unsplash.com/900x300/?watch,men');

-- Dumping structure for table watch_zone.social_apps
DROP TABLE IF EXISTS `social_apps`;
CREATE TABLE IF NOT EXISTS `social_apps` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `image` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci NOT NULL DEFAULT '0',
  `link` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci NOT NULL DEFAULT '0',
  `target` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci NOT NULL DEFAULT '0',
  `type` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

-- Dumping data for table watch_zone.social_apps: ~3 rows (approximately)
DELETE FROM `social_apps`;
INSERT INTO `social_apps` (`id`, `image`, `link`, `target`, `type`) VALUES
	(1, 'images/icon-twitter.png', 'https://twitter.com/IamWaqarHussain', 'blank', 1),
	(2, 'images/icon-insta.png', 'https://www.instagram.com/her_beard_boy', 'blank', 1),
	(3, 'images/icon-fb.png', 'https://www.facebook.com/waqar.hussain.5011/', 'blank', 1);

-- Dumping structure for table watch_zone.users
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci NOT NULL,
  `last_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci NOT NULL,
  `profession` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL,
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci NOT NULL DEFAULT '',
  `updated_at` timestamp NULL DEFAULT NULL,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci NOT NULL DEFAULT '',
  `password` text CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci NOT NULL,
  `cpassword` text CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci,
  `role` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `permissions` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `mobile` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `address` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `country` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

-- Dumping data for table watch_zone.users: ~3 rows (approximately)
DELETE FROM `users`;
INSERT INTO `users` (`id`, `first_name`, `last_name`, `profession`, `created_at`, `email`, `updated_at`, `username`, `password`, `cpassword`, `role`, `permissions`, `mobile`, `address`, `city`, `country`) VALUES
	(11, 'waqar', 'hussain', 'designer', '2022-11-02 06:16:10', 'waqaar.hussaiin@gmail.com', NULL, '', '123', '123', 'user', NULL, '03338000128', NULL, NULL, NULL),
	(12, 'Sania', 'Hussain', 'Teacher', '2022-11-07 06:38:23', 'sadiamcs900@gmail.com', NULL, '', '123', '123', 'admin', NULL, '‪+92 320 3566487‬', 'near dari saanghi road', 'RYK', 'Pakistan'),
	(13, 'azaan', 'hussain', 'youtuber', '2022-11-07 07:52:08', 'smartwiki009@gmail.com', NULL, '', '123', '123', 'user', NULL, '03338000128', NULL, NULL, NULL);

-- Dumping structure for table watch_zone.user_meta
DROP TABLE IF EXISTS `user_meta`;
CREATE TABLE IF NOT EXISTS `user_meta` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `account_num` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `phone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

-- Dumping data for table watch_zone.user_meta: ~0 rows (approximately)
DELETE FROM `user_meta`;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
