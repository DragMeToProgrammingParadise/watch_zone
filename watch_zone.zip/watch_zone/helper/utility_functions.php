<?php

//db connection
function create_db_connection(){
    $con = new mysqli("localhost", "root", "", "watch_zone");
    // Check connection
    if ($con->connect_errno) {
        echo "Failed to connect to MySQL: " . $con->connect_error;
        exit();
    }

    return $con; 
}

//CRUD
function wz_select_query($table_name = '', $where='', $columns='*'){
    $con = create_db_connection();
    $query = 'SELECT '.$columns.' FROM '.$table_name.' WHERE '.$where;
    $result = mysqli_query($con, $query);
   
   return $result;
}

// Order Status

function order_status_string($status = 0, $return = 0){
    $status_msg = 'Processing';
    if($status == 0){
        $status_msg = 'Processing';
    }else if($status == 1){
        $status_msg = 'Confirmed';
    }else if($status == 2){
        $status_msg = 'Dispatched';
    }else if($status == 3){
        $status_msg = 'Delivered';
    }

    if($return){
        return $status_msg;
    }

    echo $status_msg;
}

function wz_is_logedin(){
    if(!isset($_SESSION['user_id'])){
        header('location:login.php?msg=please login first.');
        exit;
    }
}