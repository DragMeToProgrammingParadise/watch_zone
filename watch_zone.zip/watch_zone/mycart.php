<?php  include 'partials/header.php'; 

// dd($_SESSION);
wz_is_logedin();
?>


  <!--Section: Contact v.2-->

  <div class="container mt-2 mb-5">
    <div class="contentbar">
      <!-- Start row -->
      <div class="row">
        <!-- Start col -->
        <div class="col-md-12 col-lg-12 col-xl-12">
          <div class="card m-b-30">
            <div class="card-header">
              <h5 class="card-title">Cart</h5>
            </div>
            <?php if(isset($_SESSION['cart_items'])){ ?>
            <div class="card-body">
              <div class="row justify-content-center">
                <div class="col-lg-10 col-xl-8">
                  <div class="cart-container">
                    <div class="cart-head">
                      <div class="table-responsive">
                        <table class="table table-borderless">
                          <thead>
                            <tr>
                              <th scope="col">#</th>
                              <th scope="col">Action</th>
                              <th scope="col">Photo</th>
                              <th scope="col">Product</th>
                              <th scope="col">Qty</th>
                              <th scope="col">Price</th>
                              <th scope="col" class="text-right">Total</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php 
                            //  echo '<pre>';
                            //  print_r($_SESSION['cart_items'] );
                            // exit;
                            

                            if(isset($_SESSION['cart_items'])){
                            foreach($_SESSION['cart_items'] as $key){
                
                              
                            
                            ?>
                            <tr>
                              <th scope="row"><?php echo $key['product_id'] ; ?></th>
                              <td><a href="delete-cart-product.php?pId=<?php echo $key['product_id'] ?>" class="text-danger"><img src="images/delete.png" width="24" height="24" alt=""></a></td>
                              <td>
                                
                                <img src="images/<?php echo $key['product_image'] ?>"
                                  
                                  class="img-fluid rounded" width="35" alt="product"></td>
                              <td><?php echo $key['product_name']; ?></td>
                              <td>
                                <div class="form-group mb-0">
                                  <input type="number" class="form-control cart-qty" name="cartQty1" data-product-id="<?php echo $key['product_id']; ?>" id="cartQty"
                                    value="<?php echo $key['product_quantity']; ?>">
                                </div>
                              </td>
                              <td><?php echo $key['product_price']; ?></td>
                              <td class="text-right"><?php echo $key['product_price']*$key['product_quantity']  ?></td>
                            </tr>

                            
                           <?php
                            }
                           }
                            ?>
                          </tbody>
                        </table>
                      </div>
                    </div>
                    <div class="cart-body">
                      <div class="row">
                        <div class="col-md-12 order-2 order-lg-1 col-lg-5 col-xl-6">
                          <div class="order-note">
                            <form>
                              <div class="form-group">
                                
                              </div>
                              <div class="form-group">
                                <label for="specialNotes">Special Note for this order:</label>
                                <textarea class="form-control" name="specialNotes" id="specialNotes" rows="4"
                                  placeholder="Message here"></textarea>
                              </div>
                            </form>
                          </div>
                        </div>
                        <div class="col-md-12 order-1 order-lg-2 col-lg-7 col-xl-6">
                          <div class="order-total table-responsive ">
                            <table class="table table-borderless text-right">
                              <tbody>
                              <?php 
                            //  echo '<pre>';
                            //  print_r($_SESSION['cart_items'] );
                            // exit;
                            $total = 0;
                            $delivery_charges = 300;
                            $total_amount = 0;
                            if(isset($_SESSION['cart_items'])){
                            foreach($_SESSION['cart_items'] as $key){
                
                              $total += ($key['product_price']*$key['product_quantity']);
                              
                            }}
                            $total_amount = $total + $delivery_charges;
                            ?>
                                <tr>
                                  <td>Sub Total :</td>
                                  <td><?php echo $total ; ?></td>
                                </tr>
                                <tr>
                                  <td>Delivery Charges :</td>
                                  <td><?php echo $delivery_charges ; ?></td>
                                </tr>

                                <tr>
                                  <td class="f-w-7 font-18">
                                    <h4>Amount (Rs) :</h4>
                                  </td>
                                  <td class="f-w-7 font-18">
                                    <h4><?php echo $total_amount ; ?> pkr</h4>
                                  </td>
                                </tr>
                          
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div class="cart-footer text-center">
                      <a title="Empty the cart." href="delete-cart.php?remove_all=1" class="btn btn-outline-danger my-1">Delete
                        Cart</a>
                      <a href="page-checkout.php" class="btn btn-outline-danger my-1">Order Now<i
                          class="ri-arrow-right-line ml-2"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <?php } else{ ?>
            <h3 class="text-center mt-5">Cart is empty, Lets shop with us.</h3>
            <a class="text-center mt-3 mb-5 text-decoration-none" href="index.php"href>Store</a>
            <?php }  ?>
          </div>
        </div>
        <!-- End col -->
      </div>
      <!-- End row -->
    </div>
  </div>


  <!-- Footer -->

  <?php  include 'partials/footer.php'; ?>