<?php  include 'partials/header.php';
wz_is_logedin();
?>

  <!--Section: Contact v.2-->
  <div class="container mt-2 mb-5">
    <div class="contentbar">
      <!-- Start row -->
      <div class="row">
        <!-- Start col -->
        <div class="col-md-12 col-lg-12 col-xl-12">
          <div class="card m-b-30">
            <div class="card-header">
              <h5 class="card-title">My Orders</h5>
            </div>
            <div class="card-body">
              <div class="row justify-content-center">
                <div class="col-lg-10 col-xl-8">
                  <div class="cart-container">
                    <div class="cart-head">
                    <?php 
                                $userID = @$_SESSION['user_id'];// > 0 ? $_SESSION['user_id'] : 9;
                                $con = create_db_connection();
                                $result = wz_select_query('orders', 'user_id = '.$userID);
                               
                                $srNo = 0;
                        ?> 
                        <?php if($result->num_rows > 0){ ?>

                        
                    <div class="table-responsive">
                        <table class="table table-borderless">
                          <thead>
                            <tr>
                              <th scope="col">#</th>
                              <th scope="col">Order ID</th>
                              <th scope="col">Amount</th>
                              <!--<th scope="col">Discount</th>-->
                              <th scope="col">Status</th>
                              <th scope="col">Created</th>
                              <th scope="col">Updated</th>
                              <th scope="col">Action</th>
                            </tr>
                          </thead>
                          <tbody>
                          
                          <?php
                                while ($row = mysqli_fetch_array($result)) {
                                   $srNo++;
                            ?>
                                    <tr>         
                                        <td><?php echo $srNo; ?></td>
                                        <td><?php echo @$row['tracking_num']; ?></td>
                                        <td><?php echo @$row['amount']; ?></td>
                                        <!--<td><?php echo @$row['discount']; ?></td>-->
                                        <td><?php echo order_status_string( @$row['status']); ?></td>
                                        <td><?php echo @$row['created_at']; ?></td>
                                        <td><?php echo @$row['updated_at'] == '' ? @$row['created_at'] : @$row['updated_at']; ?></td>
                                        <td><?php echo @$row['action']; ?></td>
                                        <td><a class="text-decoration-none" href='order-details.php?order-id=<?php echo @$row['tracking_num']; ?>' title="Click to show details.">Details</a></td>
                                    </tr>
                            <?php }// end of while loop ?>
                          </tbody>
                        </table>
                      </div>
                    </div>
                    <?php }else{ ?>
                        <div class="text-center mt-5">No order(s) found, Lets shop with us. <a class="text-center mt-3 mb-5 text-decoration-none" href="index.php">Store</a></div>
                        
                    <?php } ?>
                  </div>
                </div>
              </div>
            </div>
            
          </div>
        </div>
        <!-- End col -->
      </div>
      <!-- End row -->
    </div>
  </div>


  <!-- Footer -->

  <?php 

include 'partials/footer.php';

?>