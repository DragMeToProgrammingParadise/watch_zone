<?php 
        include'partials/header.php' ;
    $id=$_GET['id'];
    $con = create_db_connection();
    $query = 'DELETE FROM users WHERE id=' . $id;
    $result = mysqli_query($con, $query);
    header('location:users.php');



    include'partials/footer.php';
?> 