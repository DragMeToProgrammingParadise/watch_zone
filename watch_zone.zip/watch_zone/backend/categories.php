<?php include 'partials/header.php';
wz_is_logedin();
?>


<!--Section: Contact v.2-->
<div class="container mt-2 mb-5">
  <div class="contentbar">
    <!-- Start row -->
    <div class="row">
      <!-- Start col -->
      <div class="col-md-12 col-lg-12 col-xl-12">
        <div class="card m-b-30">
          <div class="card-header">
            <h5 class="card-title">Categories</h5>
          </div>
          <div class="card-body">
            <div class="row justify-content-center">
              <div class="col-lg-10 col-xl-8">
                <div class="cart-container">
                  <div class="cart-head">
                    <?php

                    $con = create_db_connection();
                    $query = 'SELECT * from product_categories';
                    $result = mysqli_query($con, $query);


                    $srNo = 0;
                    ?>
                    <?php if ($result->num_rows > 0) { ?>


                      <div class="table-responsive">
                        <table class="table table-borderless">
                          <thead>
                            <tr>

                              <th scope="col">#</th>
                              <th scope="col">Category ID</th>
                              <th scope="col">Name</th>
                              <th scope="col">Description</th>
                              <th scope="col">Created</th>
                              <th scope="col">Action</th>

                            </tr>
                          </thead>
                          <tbody>

                            <?php
                            while ($row = mysqli_fetch_array($result)) {
                              $srNo++;
                            ?>
                              <tr>

                                <td><?php echo $srNo; ?></td>
                                <td><?php echo @$row['id']; ?></td>
                                <td><?php echo @$row['name']; ?></td>
                                <td><?php echo @$row['description']; ?></td>
                                <td><?php echo @$row['created_at']; ?></td>
                                <td><a href="delete-category.php?id=<?php echo $row['id'] ?>" class="text-danger"><img src="../images/delete.png" width="24" height="24" alt=""></a></td>
                                <td><a class="text-decoration-none" href='edit-category.php?id=<?php echo @$row['id'] ?>' title="Click to edit category.">Edit</a></td>
                                

                              </tr>
                            <?php } // end of while loop 
                            ?>
                            
                          </tbody>
                        </table>
                        <div class="d-flex align-items-center justify-content-center text-center">
                        <a class="ml-5 btn btn-outline-danger " type="submit" href='add-category.php'>Add Category

                            </a>
                            </div>
                      </div>
                  </div>
                <?php } else { ?>
                  <div class="text-center mt-5">No categories found.</div>

                <?php } ?>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
      <!-- End col -->
    </div>
    <!-- End row -->
  </div>
</div>

</div>

<!-- footer -->

<?php include 'partials/footer.php' ?>