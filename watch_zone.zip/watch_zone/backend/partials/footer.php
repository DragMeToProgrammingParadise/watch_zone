<footer class="d-flex flex-wrap justify-content-between align-items-center py-2 my-1 border-top bg-primary text-white">
    <div class="col-md-4 d-flex align-items-center">
      <a href="/" class="mb-1 me-2 mb-md-0 text-decoration-none lh-1">
        
      </a>
      <span class="mb-1 mb-md-0 text-white">© 2022 Watch Zone, Inc</span>
    </div>
    <div class=" align-items-center justify-content-center text-center ">

      <a href="contact.php" class=" text-white text-decoration-none "> Contact Us</a>
      <a href="contact.php" class=" text-dark text-decoration-none "> | </a>
      <a href="privacy.php" class=" text-white text-decoration-none ">Privacy & Policy</a>
    </div>
    <?php
$con = new mysqli("localhost","root","","watch_zone");
// Check connection
if ($con -> connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
    exit();
} ?>
<?php 
   $query = "select * from social_apps";
          $result=mysqli_query($con,$query);
        ?>
          
    <ul class="nav col-md-4 justify-content-end list-unstyled d-flex">
   <?php while($row = mysqli_fetch_array($result)){ ?>
      <li class="ms-3">
        <a class="text-muted" href="<?php echo $row['link']; ?>" target="<?php echo $row['target']; ?>">
          <img src="../<?php echo $row['image']; ?>" alt="" class="bi" width="24" height="24">

          </image>
        </a>
      </li> <?php } ?>

      <a href="/" class="mb-3 me-2 mb-md-0 text-muted text-decoration-none lh-1">
        
      </a>
    </ul> 
  </footer>
  


<script src="
https://code.jquery.com/jquery-3.5.1.slim.min.js"
    integrity="
sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
    crossorigin="anonymous">
</script>

<script>
    $(document).ready(function(){
      if(typeof $("#cartQty") != 'undefined'){

        $("#cartQty").change(function(){
          var product_quantity = $(this).val();
          var pId = $(this).data('productId');

          window.location.href = 'update-qty-cart-product.php?pId='+pId+'&product_quantity='+product_quantity;
          return false;
        });
      }
      
  });
</script>
    
<script src="
https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
    integrity=
"sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" 
    crossorigin="anonymous">
</script>
    
<script src="
https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" 
    integrity=
"sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI"
    crossorigin="anonymous">
</script> 

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8"
    crossorigin="anonymous"></script>
</body>

</html>