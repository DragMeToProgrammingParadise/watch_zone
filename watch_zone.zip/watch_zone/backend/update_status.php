<?php

$con = new mysqli("localhost", "root", "", "watch_zone");
// Check connection
if ($con->connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli->connect_error;
    exit();
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $status = $_POST['status'];
    $tracking_num =  $_POST['order-id'];
    $sql     =      "UPDATE orders
                         SET `status` = '$status'
                         WHERE `tracking_num`  = '$tracking_num'";
    $result = mysqli_query($con, $sql);
    header('location:edit-orders.php?order-id=' . $tracking_num);
}
