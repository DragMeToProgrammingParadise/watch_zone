<?php include'partials/header.php' ?>

<?php

$showAlert = false;
$showError = false;
$exists = false;

$con = new mysqli("localhost", "root", "", "watch_zone");
// Check connection
if ($con->connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli->connect_error;
    exit();
}

$productInfoResult = wz_select_query('products', 'id = '.$_REQUEST['id']);
$productInfo = mysqli_fetch_assoc($productInfoResult);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    //file upload code

$target_dir = "../images/";
$product_image_name = strtotime(date("Y-m-d H:i:s")).'_'.$_FILES["product_image"]["name"];
//$product_image_name = $_FILES["product_image"]["name"];
//$target_file = $target_dir . basename($_FILES["product_image"]["name"]);
$target_file = $target_dir . basename($product_image_name);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));



// Check if image file is a actual image or fake image
  $check = getimagesize($_FILES["product_image"]["tmp_name"]);
  if($check !== false) {
    echo "File is an image - " . $check["mime"] . ".";
    $uploadOk = 1;
  } else {
    echo "File is not an image.";
    $uploadOk = 0;
  }

// Check if file already exists
if (file_exists($target_file)) {
  echo "Sorry, file already exists.";
  $uploadOk = 0;
}

// Check file size
if ($_FILES["product_image"]["size"] > 500000) {
  echo "Sorry, your file is too large.";
  $uploadOk = 0;
}

// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
  echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
  $uploadOk = 0;
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
  echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
  if (move_uploaded_file($_FILES["product_image"]["tmp_name"], $target_file)) {
    echo "The file ". htmlspecialchars( basename( $_FILES["product_image"]["name"])). " has been uploaded.";
  } else {
    echo "Sorry, there was an error uploading your file.";
  }
}
    //end file upload code

    $pid = $_POST['id'];
    $id = $_POST['id'];
    $name = $_POST['name'];
    $description = $_POST["description"];
    $price = $_POST["price"];
    $quantity = $_POST["quantity"];
    $image = $product_image_name;
    $category_id = $_POST["category_id"];
    //$status = $_POST["status"];
    $status = 1;

           
            $sql = "UPDATE `products` SET `name`='$name', `description`='$description', `price`='$price', `quantity`='$quantity',
            `image`='$product_image_name', `category_id`='$category_id',`status`= $status, `updated_at`=current_timestamp() where id = ".$id ;
            $result = mysqli_query($con, $sql); 

            $sqll = "SELECT * from products where id = ".$pid; 
            $row = mysqli_query($con, $sqll);
            header('location:products.php');
            // if ($result) {
            //     $showAlert = true;
                 
            // }

} //end if   


if ($showAlert) {

    echo ' <div class="alert alert-success 
            alert-dismissible fade show" role="alert">
    
            <strong>Success!</strong> Category is updated successfully. 
            <button type="button" class="close"
                data-dismiss="alert" aria-label="Close"> 
                <span aria-hidden="true">×</span> 
            </button> 
        </div> ';
}

if ($showError) {

    echo ' <div class="alert alert-danger 
            alert-dismissible fade show" role="alert"> 
        <strong>Error!</strong> ' . $showError . '
    
       <button type="button" class="close" 
            data-dismiss="alert aria-label="Close">
            <span aria-hidden="true">×</span> 
       </button> 
     </div> ';
}

if ($exists) {
    echo ' <div class="alert alert-danger 
            alert-dismissible fade show" role="alert">
    
        <strong>Error!</strong>' . $exists . '
        <button type="button" class="close" 
            data-dismiss="alert" aria-label="Close"> 
            <span aria-hidden="true">×</span> 
        </button>
       </div>';
}


?> 

<section class="vh-100" style="background-color: #eee;">
    <div class="container h-100">
        <div class="row d-flex justify-content-center align-items-center h-100">
            <div class="col-lg-12 col-xl-11">
                <div class="card text-black" style="border-radius: 25px;">
                    <div class="card-body p-md-5">
                        <div class="row justify-content-center">
                            <div class="col-md-10 col-lg-6 col-xl-5 order-2 order-lg-1">

                                <p class="text-center h1 fw-bold mb-5 mx-1 mx-md-4 mt-4">Update Product </p>

                                <form class="mx-1 mx-md-4" action="edit-product.php" method="POST" enctype="multipart/form-data">
                                    <input type="hidden" name="id" value="<?php if($_GET['id']){echo $_GET['id'];} ?>" />
                                    
                                    <div class="d-flex flex-row align-items-center mb-4">
                                        <i class="fas fa-user fa-lg me-3 fa-fw"></i>
                                        <div class="form-outline flex-fill mb-0">
                                            <input type="text" id="name" name="name" class="form-control" required  value="<?php echo $productInfo['name'] ?>" />
                                            <label class="form-label" for="name">Name</label>
                                        </div>
                                    </div>

                                    <div class="d-flex flex-row align-items-center mb-4">
                                        <i class="fas fa-user fa-lg me-3 fa-fw"></i>
                                        <div class="form-outline flex-fill mb-0">
                                            <input type="text" id="description" name="description" class="form-control" required value="<?php echo $productInfo['description']?>" />
                                            <label class="form-label" for="description">Description</label>
                                        </div>
                                    </div>

                                    <div class="d-flex flex-row align-items-center mb-4">
                                        <i class="fas fa-user fa-lg me-3 fa-fw"></i>
                                        <div class="form-outline flex-fill mb-0">
                                            <input type="text" id="price" name="price" class="form-control" required  value="<?php echo $productInfo['price']?>" />
                                            <label class="form-label" for="price">Price</label>
                                        </div>
                                    </div>

                                    <div class="d-flex flex-row align-items-center mb-4">
                                        <i class="fas fa-user fa-lg me-3 fa-fw"></i>
                                        <div class="form-outline flex-fill mb-0">
                                            <input type="text" id="quantity" name="quantity" class="form-control" required value="<?php echo $productInfo['quantity']?>" />
                                            <label class="form-label" for="quantity">Quantity</label>
                                        </div>
                                    </div>

                                    <div class="d-flex flex-row align-items-center mb-4">
                                        <i class="fas fa-user fa-lg me-3 fa-fw"></i>
                                        <div class="form-outline flex-fill mb-0">
                                            <input type="text" id="category_id" name="category_id" class="form-control" required value="<?php echo $productInfo['category_id']?>" />
                                            <label class="form-label" for="category_id">Category ID</label>
                                        </div>
                                    </div>

                                    <div class="d-flex justify-content-center mx-4 mb-3 mb-lg-4">

                                    <button type="submit" class="btn btn-outline-danger">Update
                                    </button>
                                    </div>
                            </div>
                            <div class="col-md-10 col-lg-6 col-xl-7 d-flex align-items-center justify-content-center order-1 order-lg-2">
                                <img src="../images/<?php echo $productInfo['image']; ?>" class="img-fluid opacity-75 rounded" alt='product_img' />
                               <br /> <input type="file" name='product_image' />
                            </div>

                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>

</section>

