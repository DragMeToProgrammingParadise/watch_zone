
<?php include'partials/header.php' ?>

<?php
wz_is_logedin();
$query = "select * from products where category_id = '5'";
  $result = mysqli_query($con, $query);
  ?>

<div class=" align-items-center justify-content-center text-center mt-4 mb-4">
    <h1 class="font-monospace">Dashboard</h1>
</div>

<div class="row row-cols-1 row-cols-md-4 g-2 mt-1 mb-2">

  <div class="col">
    <div class="card">
      <img src="http://source.unsplash.com/300x300/?watch,categories" class="card-img-top" alt="...">

      <div class=" text-center mb-2 mt-2">
        <a class="btn btn-outline-danger" href="categories.php">Categories</a>
      </div>
    </div>
  </div>

  <div class="col">
    <div class="card">
      <img src="http://source.unsplash.com/300x300/?watch,products" class="card-img-top" alt="...">

      <div class=" text-center mb-2 mt-2">
        <a class="btn btn-outline-danger" href="products.php">Products</a>
      </div>
    </div>
  </div>

  <div class="col">
    <div class="card">
      <img src="http://source.unsplash.com/300x300/?watch,orders" class="card-img-top" alt="...">

      <div class=" text-center mb-2 mt-2">
        <a class="btn btn-outline-danger" href="orders.php">Orders</a>
      </div>
    </div>
  </div>

  <div class="col">
    <div class="card">
      <img src="http://source.unsplash.com/300x300/?website,users" class="card-img-top" alt="...">

      <div class=" text-center mb-2 mt-2">
        <a class="btn btn-outline-danger" href="users.php">Users</a>
      </div>
    </div>
  </div>

  
</div>
        


<?php include'partials/footer.php' ?>