<?php 

include 'partials/header.php';
wz_is_logedin();
?>

  <!-- Personal Profile -->
  
  <?php
$con = new mysqli("localhost", "root", "", "watch_zone");
// Check connection
if ($con->connect_errno) {
  echo "Failed to connect to MySQL: " . $mysqli->connect_error;
  exit();
}
$id = @$_SESSION['user_id'];
$query = "select * from users where id = '$id'";
  $result = mysqli_query($con, $query);
?>

  <section class="vh-100" style="background-color: #f4f5f7;">
    <div class="container py-5 h-100">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col col-lg-6 mb-4 mb-lg-0">
        <?php
    while ($row = mysqli_fetch_array($result)) {
  ?>
          <div class="card mb-3" style="border-radius: .5rem;">
            <div class="row g-0">
              <div class="col-md-4 gradient-custom text-center text-dark"
                style="border-top-left-radius: .5rem; border-bottom-left-radius: .5rem;">
                <img src="http://source.unsplash.com/96x96/?man,avatar"
                  alt="Avatar" class="img-fluid mt-5 mb-2 rounded-circle" style="width: 80px;" />
                <h5><?php echo $row['first_name']." ".$row['last_name']; ?></h5>
                <p><?php echo $row['profession'] ?></p>
                <i class="far fa-edit mb-5"></i>
              </div>
              <div class="col-md-8">
                <div class="card-body p-4">
                  <h6>Information</h6>
                  <hr class="mt-0 mb-4">
                  <div class="row pt-1">
                    <div class="col-6 mb-3">
                      <h6>Email</h6>
                      <p class="text-muted"><?php echo $row['email']; ?></p>
                    </div>
                    <div class="col-6 mb-3">
                      <h6>Phone</h6>
                      <p class="text-muted"><?php echo $row['mobile']; ?></p>
                    </div>
                  </div>
                 
                    <!-- <div class="col-6 mb-3">
                      <h6>Address</h6>
                      <p class="text-muted">
                       <?php echo $row['address']." ".$row['city']." ".$row['country']; ?>
                      </p>
                    </div> -->
                    
                  <div class="d-flex justify-content-start ">
                    <a href="#!"><i class="fab fa-facebook-f fa-lg me-3"></i></a>
                    <a href="#!"><i class="fab fa-twitter fa-lg me-3"></i></a>
                    <a href="#!"><i class="fab fa-instagram fa-lg"></i></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <?php } ?>
        </div>
      </div>
    </div>
  </section>


  <!-- Footer -->

  <?php 

include 'partials/footer.php';

?>