<?php 
        include'partials/header.php' ;
    $id=$_GET['id'];
    $con = create_db_connection();
    $query = 'DELETE FROM orders WHERE id=' . $id;
    $result = mysqli_query($con, $query);
    header('location:orders.php');



    include'partials/footer.php';
