<?php include 'partials/header.php';
$con = create_db_connection();

$tracking_num =  $_GET['order-id'];
$order_detail_result = wz_select_query('orders LEFT JOIN order_meta ON orders.id = order_meta.orders_id', 'tracking_num = "' . $tracking_num . '"');
$result = wz_select_query('orders LEFT JOIN order_meta ON orders.id = order_meta.orders_id', 'tracking_num = "' . $tracking_num . '"');

$order_details = mysqli_fetch_assoc($order_detail_result);
// echo "<pre>";
// print_r($order_details);
// exit;

?>

<div class="container mt-2 mb-2 mb-3">
    <div class="card-header">
        <h2 class="card-title text-center">Order details</h2>
    </div>
    <section class="h-100 h-custom " style="background-color: #eee;">

        <div class="container py-5 h-100">
            <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col-lg-8 col-xl-6">
                    <div class="card border-top border-bottom border-3" style="border-color: #ff4949 !important;">
                        <div class="card-body p-5">

                            <p class="lead fw-bold mb-5" style="color: #ff4949;">Purchase Reciept</p>

                            <div class="row">
                                <div class="col mb-3">
                                    <p class="small text-muted mb-1">Date</p>
                                    <p><?php echo $order_details['created_at']; ?></p>
                                </div>
                                <div class="col mb-3">
                                    <p class="small text-muted mb-1">Order No.</p>
                                    <p><?php echo $order_details['orders_id'] ?></p>
                                </div>
                            </div>
                            <?php
                            while ($row = mysqli_fetch_assoc($result)) {
                            ?>

                                <div class="mx-n5 px-5 py-4" style="background-color: #f2f2f2;">
                                    <div class="row">
                                        <div class="col-md-8 col-lg-9">
                                            <p><?php echo $row['product_name'] . $row['id'] ?></p>
                                        </div>
                                        <div class="col-md-4 col-lg-3">
                                            <p><?php echo $row['sub_total'] ?></p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-8 col-lg-9">
                                            <p> Quantity </p>
                                        </div>
                                        <div class="col-md-4 col-lg-3">
                                            <p><?php echo $row['quantity'] ?></p>
                                        </div>
                                    </div>

                                </div>
                            <?php } ?>
                            <div class="row">
                                <div class="col-md-8 col-lg-9">
                                    <p class="mb-0">Deliver Charges</p>
                                </div>
                                <div class="col-md-4 col-lg-3">
                                    <p class="mb-0"><?php echo $order_details['delivery_charges'] ?></p>
                                </div>
                            </div>
                            <div class="row my-4">
                                <div class="col-md-4 offset-md-8 col-lg-3 offset-lg-9">
                                    <p class="lead fw-bold mb-0" style="color: #ff4949;"><?php echo $order_details['amount'] ?></p>
                                </div>
                            </div>

                            <p class="lead fw-bold mb-4 pb-2" style="color: #ff4949;">Tracking Order</p>

                            <div class="row">
                                <div class="col-lg-12">



                                    <div class="dropdown border-danger">
                                        <form action="update_status.php" method="POST">
                                            <input type="hidden" value="<?php echo $_GET['order-id']; ?>" name="order-id">
                                            <select name="status">
                                                <option value="0" <?php if ($order_details['status'] == '0') {
                                                                        echo "selected";
                                                                    } ?>>Processing</option>
                                                <option value="1" <?php if ($order_details['status'] == '1') {
                                                                        echo "selected";
                                                                    } ?>>Confirmed</option>
                                                <option value="2" <?php if ($order_details['status'] == '2') {
                                                                        echo "selected";
                                                                    } ?>>Dispatched</option>
                                                <option value="3" <?php if ($order_details['status'] == '3') {
                                                                        echo "selected";
                                                                    } ?>>Delivered</option>
                                            </select>
                                            <button class="ml-5 btn btn-outline-danger" type="submit">Submit

                                            </button>
                                        </form>

                                    </div>



                                </div>
                            </div>

                            <p class="mt-4 pt-2 mb-0">Want any help? <a href="contact.php" style="color: #ff4949;">Please contact
                                    us</a></p>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- <section class="h-100 h-custom" style="background-color: #eee;">

        <div class="container py-5 h-100">
            <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col-lg-8 col-xl-6">
                    <div class="card border-top border-bottom border-3" style="border-color: #ff4949 !important;">
                        <div class="card-body p-5">

                            <p class="lead fw-bold mb-5" style="color: #ff4949;">Purchase Reciept</p>

                            <div class="row">
                                <div class="col mb-3">
                                    <p class="small text-muted mb-1">Date</p>
                                    <p>10 April 2021</p>
                                </div>
                                <div class="col mb-3">
                                    <p class="small text-muted mb-1">Order No.</p>
                                    <p>012j1gvs356c</p>
                                </div>
                            </div>

                            <div class="mx-n5 px-5 py-4" style="background-color: #f2f2f2;">
                                <div class="row">
                                    <div class="col-md-8 col-lg-9">
                                        <p>BEATS Solo 3 Wireless Headphones</p>
                                    </div>
                                    <div class="col-md-4 col-lg-3">
                                        <p>£299.99</p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-8 col-lg-9">
                                        <p class="mb-0">Shipping</p>
                                    </div>
                                    <div class="col-md-4 col-lg-3">
                                        <p class="mb-0">£33.00</p>
                                    </div>
                                </div>
                            </div>

                            <div class="row my-4">
                                <div class="col-md-4 offset-md-8 col-lg-3 offset-lg-9">
                                    <p class="lead fw-bold mb-0" style="color: #ff4949;">£262.99</p>
                                </div>
                            </div>

                            <p class="lead fw-bold mb-4 pb-2" style="color: #ff4949;">Tracking Order</p>

                            <div class="row">
                                <div class="col-lg-12">

                                    <div class="horizontal-timeline">

                                        <ul class="list-inline items d-flex justify-content-between">
                                            <li class="list-inline-item items-list">
                                                <p class="py-1 px-2 rounded text-white"
                                                    style="background-color: #ff4949;">Ordered</p
                                                    class="py-1 px-2 rounded text-white"
                                                    style="background-color: #f37a27;">
                                            </li>
                                            <li class="list-inline-item items-list">
                                                <p class="py-1 px-2 rounded text-white"
                                                    style="background-color: #ff4949;">Shipped</p
                                                    class="py-1 px-2 rounded text-white"
                                                    style="background-color: #f37a27;">
                                            </li>
                                            <li class="list-inline-item items-list">
                                                <p class="py-1 px-2 rounded text-white"
                                                    style="background-color: #ff4949;">On the way
                                                </p>
                                            </li>
                                            <li class="list-inline-item items-list text-end" style="margin-right: 8px;">
                                                <p style="margin-right: -8px;">Delivered</p>
                                            </li>
                                        </ul>

                                    </div>

                                </div>
                            </div>

                            <p class="mt-4 pt-2 mb-0">Want any help? <a href="contact.html"
                                    style="color: #ff4949;">Please contact
                                    us</a></p>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
</div>


<?php include 'partials/footer.php' ?>