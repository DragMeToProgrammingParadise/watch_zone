<?php include'partials/header.php' ;

$id=$_GET['id'];
$con = create_db_connection();
$query = 'DELETE FROM products WHERE id=' . $id;
$result = mysqli_query($con, $query);

header('location:products.php');

?>

<?php include'partials/footer.php' ?>