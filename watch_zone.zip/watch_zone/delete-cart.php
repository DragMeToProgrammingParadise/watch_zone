<?php  
session_start();
 if (isset($_GET['remove_all'])){
    unset($_SESSION['cart_items']);
    header("Location: mycart.php");
}
?>