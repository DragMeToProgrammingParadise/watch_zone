<?php

include 'partials/header.php';

// if(!isset($_SESSION['email'])){
//     echo ' <div class="alert alert-danger 
//             alert-dismissible fade show" role="alert">
    
//         <strong>Error!</strong> You are not logged In...Please Login now
//         <button type="button" class="close" 
//             data-dismiss="alert" aria-label="Close"> 
//             <span aria-hidden="true">×</span> 
//         </button>
//        </div>';
// }

if (isset($_SESSION['cart_items']) && isset($_SESSION['email']) && $_SERVER['REQUEST_METHOD'] == 'POST') {
    $pId = @$_POST['pro_id'];
    $sub_total = $total_price = $delivery_charges = 0;

    $fname = $_POST["first_name"];
    $lname = $_POST["last_name"];
    $mobile = $_POST["mobile"];
    $email = $_POST["email"];
    $address = $_POST["address"];
    $country = $_POST["country"];
    $city = $_POST["city"];
    $zip = $_POST["zip"];
    $payment = $_POST["payment"];
    
    $all_products = @$_POST["all_products"];
    
    $products_to_be_added = isset($_POST['all_products']) ? $_SESSION['cart_items'] : array($pId => $_SESSION['cart_items'][$pId]);

    foreach ($products_to_be_added as $key) {
            $delivery_charges = $key["product_delivery_charges"];
            $sub_total = ($key['product_price'] * $key['product_quantity']);
            $total_price += $sub_total;
    }
    // echo '<pre>';
    // echo $total_price;
    // print_r($_SESSION['cart_items']);
    // exit;
    $total_price = $total_price + $delivery_charges;
    $user_id = $_SESSION['user_id'];
    $tracking_num = 'WTCHZN-'. $user_id. rand(111111111, 999999999);

    $sql = "INSERT INTO `orders` ( `first_name`, `last_name`,  `delivery_charges`, `amount`,`mobile`, `email`, `address`,
          `country`, `city`, `zip`, `payment`, `created_at`, `user_id`, `tracking_num`) VALUES ('$fname', '$lname','$delivery_charges ',' $total_price', '$mobile', '$email', '$address',
          '$country', '$city', '$zip', '$payment', current_timestamp(),'$user_id', '$tracking_num')";
    $result = mysqli_query($con, $sql);

    $order_id = mysqli_insert_id($con);
    // echo '<pre>';
    // print_r($_SESSION['cart_items']);
    // exit;
    foreach ($products_to_be_added as $key) {
        // echo '<pre>';
        // print_r($_SESSION['cart_items']);
            $sub_totall     = ($key['product_price'] * $key['product_quantity']);
            $product_name   =  $key["product_name"];
            $description    = $key["product_description"];
            $quantity       = $key["product_quantity"];
            $price          = $key["product_price"];
            $sub_total      = $sub_totall;

            $total_amount = $key["product_name"];

            $sql = "INSERT INTO `order_meta` ( `product_name`, `description`, `quantity`, `price`,
                    `sub_total`, `orders_id`) VALUES ('$product_name', '$description', '$quantity', '$price', '$sub_total',
                    '$order_id')";

            $result = mysqli_query($con, $sql);
    }
    if ( $order_id ) {
        header('location:my-orders.php');
        echo ' <div class="alert alert-danger 
        alert-dismissible fade show" role="alert">
    
    <strong>Error!</strong> Thanks for shopping with us.
    <button type="button" class="close" 
        data-dismiss="alert" aria-label="Close"> 
        <span aria-hidden="true">×</span> 
    </button>
    </div>';
    }
} else {
    header('location:login.php');
    echo ' <div class="alert alert-danger 
    alert-dismissible fade show" role="alert">

<strong>Error!</strong> You are not logged In...Please Login now
<button type="button" class="close" 
    data-dismiss="alert" aria-label="Close"> 
    <span aria-hidden="true">×</span> 
</button>
</div>';
}
