<?php
include "partials/header.php";

if ( !isset( $_SESSION['cart_items'] ) ) {
    $_SESSION['cart_items'] = array();
}

 $pId = $_GET['pId'];
 

 $query = "select * from products where id = '$pId'";
 $result = mysqli_fetch_array(mysqli_query($con,$query));
 $product_quantity = isset($_SESSION['cart_items'][$result['id']]['product_quantity']) ? 
                            $_SESSION['cart_items'][$result['id']]['product_quantity'] + 1 : 1; 
                           
//  echo '<pre>';

$cartArray = array(
    'product_id' => $result['id'],
    'product_quantity' =>  $product_quantity,
    'product_name' =>$result['name'],
    'product_description'=>$result['description'],
    'product_price' =>$result['price'],
    'product_delivery_charges' =>"300",
    'product_image' => $result['image']
  );

if(isset($_SESSION['cart_items']) && !empty($_SESSION['cart_items']))
{
    $productIDs = [];
    foreach($_SESSION['cart_items'] as $cartKey =>$cartItem)
    {
        $productIDs[] = $cartItem['product_id'];
        if($cartItem['product_id'] ==  $pId )
        {

           
            $_SESSION['cart_items'][$cartKey]['total_price'] = "5";
            break;
        }
    }

    if(!in_array( $pId ,$productIDs))
    {
        $_SESSION['cart_items'][$pId]= $cartArray;
    }

    $successMsg = true;
    
}
else
{
    $_SESSION['cart_items'][$pId]= $cartArray;
    $successMsg = true;
}
if(is_array($_SESSION['cart'])){
 if(!in_array($_GET['pId'], $_SESSION['cart'])){
    array_push($_SESSION['cart'], $_GET['pId']);
    $_SESSION['message'] = 'Product added to cart';
}
else{
    $_SESSION['message'] = 'Product already in cart';
}
}
header('location: mycart.php');
 ?>


<?php 

include 'partials/footer.php';

?>