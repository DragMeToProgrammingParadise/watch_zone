<?php
session_start();
 if(isset($_SESSION['cart_items'])){
    $pId = $_GET['pId'];
    $qty = $_GET['product_quantity'];

    $_SESSION['cart_items'][$pId]['product_quantity'] = $qty;
 }
header('location:mycart.php');
?>