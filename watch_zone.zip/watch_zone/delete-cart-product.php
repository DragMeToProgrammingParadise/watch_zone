<?php
session_start();
 if(isset($_SESSION['cart_items'])){
$pId = $_GET['pId'];
// dd($pid);
unset($_SESSION['cart_items'][$pId]); 
if(count($_SESSION['cart_items']) < 1){
    unset($_SESSION['cart_items']);
}
 }
header('location:mycart.php');
?>