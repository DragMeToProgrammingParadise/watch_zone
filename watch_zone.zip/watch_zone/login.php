<?php

$showError = false;
if ($showError) {

    echo ' <div class="alert alert-danger 
            alert-dismissible fade show" role="alert"> 
        <strong>Error!</strong> ' . $showError . '
    
       <button type="button" class="close" 
            data-dismiss="alert aria-label="Close">
            <span aria-hidden="true">×</span> 
       </button> 
     </div> ';
}
$con = new mysqli("localhost", "root", "", "watch_zone");
// Check connection
if ($con->connect_errno) {
  echo "Failed to connect to MySQL: " . $mysqli->connect_error;
  exit();
}
  
if($_SERVER['REQUEST_METHOD']=='POST'){
$email = $_POST['email'];
$password = $_POST['password']; 
//  print_r($_POST); exit;
$select = "SELECT * from users where email ='$email' AND password ='$password' AND role!='admin'";
$result = mysqli_query($con, $select);
$data = mysqli_fetch_array($result);
$row = mysqli_num_rows($result);
if(isset($data['id'])){

$id = $data['id'];
}
if($row==1){
    session_start();
    $_SESSION['login']=true;
    $_SESSION['email']=$email;
    $_SESSION['user_id']=$id;

    header('location:index.php');

}
else{
     echo "Invalid user...!!";
    //$showError = "Invalid...";
}
}
?>

<?php 

include 'partials/header.php';

?>

    <div class="text-center my-4">
        <a class="btn btn-outline-danger" href="index.html">Watch Zone</a>
    </div>

    <section class="w-100 p-4 d-flex justify-content-center pb-2">
        <form style="width: 22rem;" method="POST">
            <!-- Email input -->
            <div class="form-outline mb-4">
                <input type="email" id="email" name = "email" class="form-control">
                <label class="form-label" for="email" style="margin-left: 0px;">Email address</label>
                <div class="form-notch">
                    <div class="form-notch-leading" style="width: 9px;"></div>
                    <div class="form-notch-middle" style="width: 88.8px;"></div>
                    <div class="form-notch-trailing"></div>
                </div>
            </div>

            <!-- Password input -->
            <div class="form-outline mb-4">
                <input type="password" id="password" name="password" class="form-control">
                <label class="form-label" for="password" style="margin-left: 0px;">Password</label>
                <div class="form-notch">
                    <div class="form-notch-leading" style="width: 9px;"></div>
                    <div class="form-notch-middle" style="width: 64px;"></div>
                    <div class="form-notch-trailing"></div>
                </div>
            </div>

            <!-- 2 column grid layout for inline styling -->
            <div class="row mb-4">
                <div class="col d-flex justify-content-center">
                    <!-- Checkbox -->
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="form2Example31" checked="">
                        <label class="form-check-label" for="form2Example31"> Remember me </label>
                    </div>
                </div>

                <div class="col">
                    <!-- Simple link -->
                    <a href="#!">Forgot password?</a>
                </div>
            </div>

            <!-- Submit button -->
            <div class="text-center mb-3">
                <button type="submit" class="btn btn-outline-danger">Login
                </button>

            </div>
            <!-- Register buttons -->
            <div class="text-center">
                <p>Not a member? <a href="signup.html">Register</a></p>

            </div>
        </form>
    </section>

    <!-- Footer -->

    <?php 

include 'partials/footer.php';

?>